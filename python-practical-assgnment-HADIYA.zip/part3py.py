num = float(input("Enter a number: "))

if num > 0:
    print("The number is positive")
elif num < 0:
    print("The number is negative")
else:
    print("The number is zero")

#grading system
print("#grading system")
marks = float(input("Enter your marks: "))

if marks >= 50:
    print("Grade: A")
elif marks >= 40:
    print("Grade: B")
elif marks >= 30:
    print("Grade: C")
elif marks >= 20:
    print("Grade: D")
else:
    print("Grade: F")