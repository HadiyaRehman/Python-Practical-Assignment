# Task 1 - Handle division by zero using try/except
print("=== Division by Zero ===")

try:
    num = int(input("Enter a number: "))
    result = 10 / num
    print("Result:", result)
except ZeroDivisionError:
    print("Error! Cannot divide by zero!")

# Task 2 - Multiple exceptions
print("\n=== Multiple Exceptions ===")

try:
    a = int(input("Enter a number: "))
    b = int(input("Enter another number: "))
    result = a / b
    print("Result:", result)
except ZeroDivisionError:
    print("Error! Division by zero!")
except ValueError:
    print("Error! Please enter a valid number!")
except Exception as e:
    print("Something went wrong:", e)
finally:
    print("program finished")