#Print numbers from 1 to 20 using a for loop
for i in range (1,20):
    print(i)

#Print even numbers using while loop
print("#Print even numbers using while loop")
i = 1
while i <= 20:
    print(i)
    i+=1

#Nested loop to display a multiplication table
print("#nested loop to display a multiplication table")
n= int(input("Enter number: "))
i = 1

while i <= 10:
    print(n, "x", i, "=", n * i)
    i += 1