# Task 1 - Student Class
class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

    def display_info(self):
        print("=== Student Info ===")
        print("Name:", self.name)
        print("Age:", self.age)
        print("Grade:", self.grade)
# Task 2 - Teacher Class
class Teacher(Student):
    def __init__(self, name, age, grade, subject):
        super().__init__(name, age, grade)
        self.subject = subject

    def display_info(self):
        print("=== Teacher Info ===")
        print("Name:", self.name)
        print("Age:", self.age)
        print("Grade:", self.grade)
        print("Subject:", self.subject)
# Student 1
s1 = Student("Hadiya", 20, "A")
s1.display_info()
print()
# Student 2
s2 = Student("Sara", 19, "B+")
s2.display_info()
print()

# Teacher
t1 = Teacher("Sir Ali", 35, "N/A", "Python")
t1.display_info()