print("Hello Hunarmand punjab")
#variables(different data type)
name= "Hadiya Rehman"
age= 19
gpa=3.5
print("Hadiya rehman")
print("19")
print("3.5")
#arthmetmetic operations
a=2007
b=10
print(a+b)
print(a-b)
print(a*b)
print(a/b)
#type of conversion
x=100
y=int(x)  #convert string to int
print(y)
print(type(y))
a= 50
b=float(a) #covert int to float
print(b)
print(type(b))
