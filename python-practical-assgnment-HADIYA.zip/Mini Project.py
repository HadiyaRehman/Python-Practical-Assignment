# Simple Student Management System

students = []
def load_students():
    students.append({"name": "Hadiya", "age": "20", "grade": "A"})
    students.append({"name": "Sara",   "age": "19", "grade": "B+"})
    students.append({"name": "Ahmed",  "age": "21", "grade": "B"})
    students.append({"name": "Ali",    "age": "22", "grade": "C"})
    students.append({"name": "Zara",   "age": "18", "grade": "A+"})
    print(" 5 Students loaded!")

def add_student():
    print("\n--- Add Student ---")
    name = input("Enter Name: ")
    age = input("Enter Age: ")
    grade = input("Enter Grade: ")
    student = {"name": name, "age": age, "grade": grade}
    students.append(student)
    with open("students.txt", "a") as f:
        f.write(f"Name: {name} | Age: {age} | Grade: {grade}\n")
    print(f" Student '{name}' added!")

def view_students():
    print("\n--- All Students ---")
    if len(students) == 0:
        print("No students found!")
        return
    for i, s in enumerate(students, 1):
        print(f"{i}. {s['name']}")
    num = int(input("\nKis student ki detail dekhni hai? (number): "))
    if num < 1 or num > len(students):
        print("Invalid number!")
        return
    s = students[num-1]
    print(f"\nName:  {s['name']}")
    print(f"Age:   {s['age']}")
    print(f"Grade: {s['grade']}")

def update_student():
    print("\n--- All Students ---")
    for i, s in enumerate(students, 1):
        print(f"{i}. {s['name']}")
    if len(students) == 0:
        return
    num = int(input("\nEnter student number to update: "))
    if num < 1 or num > len(students):
        print(" Invalid number!")
        return
    print("Leave blank to keep same value")
    name = input("New Name: ")
    age = input("New Age: ")
    grade = input("New Grade: ")
    if name:
        students[num-1]["name"] = name
    if age:
        students[num-1]["age"] = age
    if grade:
        students[num-1]["grade"] = grade
    print("Student updated!")

def delete_student():
    print("\n--- All Students ---")
    for i, s in enumerate(students, 1):
        print(f"{i}. {s['name']}")
    if len(students) == 0:
        return
    num = int(input("\nEnter student number to delete: "))
    if num < 1 or num > len(students):
        print(" Invalid number!")
        return
    removed = students.pop(num-1)
    print(f" Student '{removed['name']}' deleted!")

def main():
    load_students()
    while True:
        print("\n============================")
        print("  Student Management System")
        print("============================")
        for i, s in enumerate(students, 1):
            print(f"{i}. {s['name']}")
        print("----------------------------")
        print("A. Add Student")
        print("U. Update Student")
        print("D. Delete Student")
        print("E. Exit")
        print("============================")

        choice = input("Student number ya option (A/U/D/E): ").strip()

        if choice.isdigit():
            num = int(choice)
            if num < 1 or num > len(students):
                print(" Invalid number!")
            else:
                s = students[num-1]
                print(f"\nName:  {s['name']}")
                print(f"Age:   {s['age']}")
                print(f"Grade: {s['grade']}")
        elif choice.upper() == "A":
            add_student()
        elif choice.upper() == "U":
            update_student()
        elif choice.upper() == "D":
            delete_student()
        elif choice.upper() == "E":
            print("\n Goodbye!")
            break
        else:
            print(" Invalid!")

main()