#arthmetic operators
x = 2007
y = 10
print(x + y)
print(x - y)
print(x * y)
print(x / y)
print(x % y)
print(x ** y)
print(x // y) 
#comparison operators
x= 2007
y = 10
print(x == y)
print(x!=y)
print(x < y)
print(x >= y)
print(x <= y)
#logical operators
x = 9
print("logical operators")
print(x > 0 and x < 10)
print(x < 9 or x > 10)
print(not(x > 3 and x < 10))
#assignment operators
numbers = [1, 5, 0, 10, 5,6,7,9]
print ("assignment oprators")
if (count := len(numbers)) > 3:
    print(f"List has {count} elements")
    #bitwise operators
    x=2007
    y=10
    print("bitwise operators" )
    print(x&y)
    print(x|y)
    print (x ^ y)
    print( ~x )
    #EXPRESSION WITH MULTIPLE OPERATORS
    x=2007
    y=10
    print("expression amd multiple operators")
    print(x%y)
    print(x > y)
    print (x | y)
    print(x==y)
    print(x&y)
    print(x<y)
    print(x**y)