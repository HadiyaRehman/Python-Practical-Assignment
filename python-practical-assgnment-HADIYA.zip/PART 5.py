# create a func to add two num
def add_numbers(a, b):
   result = a + b
   return result

# Take input from user
num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))

answer = add_numbers(num1, num2)
print("Sum:", answer)

#Function to check if a number is prime
print("# func check if num is prime")

def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, n):
     if n % i == 0:
            return False
    return True

# Calling the function
num = int(input("Enter a number: "))

if is_prime(num):
    print(num, "is a Prime number ")
else:
    print(num, "is NOT a Prime number ")

#Demonstrate default arguments, *args, **kwargs 
print("#argument")
def greet(name, message="Hello"):
    print(message, name)
greet("Hadiya", "Good Morning")

# args & kwargs
print("#args & kwargs")

def show_info(role="Student", *args, **kwargs):
    print("Role:", role)
    print("Subjects:", args)
    print("Details:", kwargs)

show_info("student", "Math", "Science",
           name="hadiya", age=19)