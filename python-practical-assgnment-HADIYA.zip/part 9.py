
import math
print("=== Math Module ===")
print("Square root of 25:", math.sqrt(25))
print("Square root of 144:", math.sqrt(144))
print("Factorial of 5:", math.factorial(5))
print("Factorial of 7:", math.factorial(7))
print("Pi value:", math.pi)

# IMPORT RANDOM MODULE
import random
print("\n=== Random Module ===")
print("Random number 1-10:", random.randint(1, 10))
print("Random number 1-100:", random.randint(1, 100))
print("Random choice:", random.choice(["apple", "mango", "banana"]))