#student dictionary
def get_student(number):
    students = {
        1: {"name": "Ali", "age": 20, "grade": "A"},
        2: {"name": "Sara", "age": 19, "grade": "B"},
        3: {"name": "Ahmed", "age": 21, "grade": "A+"}
    }
    
    if number in students:
        return students[number]
    else:
        return "Student not found!"
# Get number from user
num = int(input("Enter student number (1-3): "))

# Call function
result = get_student(num)

print("\nStudent Info:", result)
#loop
print("\nStudent Info:")
for key, value in result.items():
    print(key, ":", value)