items = ["Apple", "Banana", "Cherry", "Mango", "Orange"]

for item in items:
    print(item)

# index number
for i in range(len(items)):
    print("index", i, "=", items[i])

#create a tuple
print("create a tuple")
fruits = ("Apple", "Banana", "Cherry", "Mango", "Orange")

print("Tuple:", fruits)
print("Type:", type(fruits))

try:
    fruits[0] = "Grapes"
except TypeError as e:
    print("\nError when trying to modify:", e)

print("\nTuple remains unchanged")
#create two sets
print("#sets")
set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}
# Union 
union_set = set1.union(set2)
# Intersection 
intersection_set = set1.intersection(set2)
# Difference 
difference_set = set1.difference(set2)
# Print results
print("Set 1:", set1)
print("Set 2:", set2)
print("Union:", union_set)
print("Intersection:", intersection_set)
print("Difference (set1 - set2):", difference_set)