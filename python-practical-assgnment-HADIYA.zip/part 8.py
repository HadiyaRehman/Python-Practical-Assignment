#1.Create a text file and write content
file = open("student.txt", "w")
file.write("welcome to python\n")
file.write("Name: Hadiya\n")
file.write("Age: 20\n")
file.write("Grade: A\n")
file.close()
print("File created and content written!")
#2.Read the file content and display
file = open("student.txt", "r")
content = file.read()
file.close()
print("\nFile Content:")
print(content)
#3.Append data to the file
file = open("student.txt", "a")
file.write("City: Karachi\n")
file.close()
print("Data appended!")
#Read again to show appended data
file = open("student.txt", "r")
print("\nUpdated File Content:")
print(file.read())
file.close()
